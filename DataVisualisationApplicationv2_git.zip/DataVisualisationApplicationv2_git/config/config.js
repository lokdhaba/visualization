﻿module.exports = {

    'secret': 'ilovescotchyscotch',
    'database': 'ds030829.mlab.com:30829/elections'

};